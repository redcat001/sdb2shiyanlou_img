# 工具简介
该工具主要用于定时解析主SSQL的日志中新增的DDL操作语句并下发到各备SSQL执行，同时能过滤日志中执行失败的DDL操作语句。

# 工具使用

注意：本程序需运行在主SSQL服务器上，即能够执行DDL操作的

## 配置SSQL免密登录
若pgsql开启了用户鉴权，需要创建元数据同步用户以及配置免密登录
1. 创建元数据同步用户
    ```bash
    bin/createuser -P -s -e sdbadmin
    ```

2. 配置免密登录，在ssql的应用用户的home目录下，创建`.pgpass`文件，按照主机名:端口号:数据库:用户名:密码(明文)的格式填写，并将文件权限设置为0600
    ```bash
    vi ~/.pgpass
    *:*:*:sdbadmin:sdbadmin
    :wq
    chmod 0600 .pgpass
    ```

## SSQL配置
```config
logging_collector = on
log_destination = 'csvlog'
# 审计日志存放目录
log_directory = 'pg_log'
# 审计日志文件名格式
log_filename = 'postgresql-%Y-%m-%d_%H%M%S.log'
# 记录登录信息
log_connections = on
# 记录登出信息
log_disconnections = on
# 日志文件大小若小于20MB时，28天后新建日志文件记录
log_rotation_age = 28d
# 日志文件大小超过20MB时，新建日志文件记录
log_rotation_size = 20MB
# 记录DDL操作
log_statement = 'ddl'
```


## 工具配置

```config
[ssql]
# 目标SSQL服务名列表,逗号(,)分隔
hosts = 172.17.0.2
# ssql服务节点
port = 5433
# ssql同步用户
pgsql_user = sdbadmin
# ssql安装目录
install_dir = /opt/sequoiasql/postgresql
# ssql数据目录
data_dir = /opt/sequoiasql/postgresql/database/5432

[execute]
# 执行时间间隔，单位：秒
interval_time = 5
# 执行日志目录
log_directory = /home/sdbadmin
# 执行日志文件前缀
log_file_prefix = SsqlDDL
# 运行日志级别
log_level = info

[parse]
# 解析日志目录
parse_log_directory = /opt/sequoiasql/postgresql/database/5432/pg_log
# 最后解析的文件
last_parse_file =
# 最后解析日志行
last_parse_row =
```

## 运行工具
将config和SsqlDisseminateDDL放置同一目录，在sdbadmin用户下，执行以下命令：
```bash
python /home/sdbadmin/SsqlDisseminateDDL &
```
***注：每台SSQL服务器的登录用户密码需相同***

## 配置系统定时任务

本操作的目的是利用操作系统的定时任务机制，定时检查程序是否在运行，若在运行则不操作，否则重新运行程序

```bash
crontab -e
# 在出现的编辑界面中输入以下内容
# 每一分钟运行一次
*/1 * * * * python  /home/sdbadmin/SsqlDisseminateDDL &
```

