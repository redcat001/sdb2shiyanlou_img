var db = new Sdb()
db.dropCS("sample")
db.createCS("sample").createCL("department")
db.getCS("sample").createCL("employee")
db.getCS("sample").createCL("project")
db.getCS("sample").createCL("projact")
db.getCS("sample").createCL("empprojact")
db.getCS("sample").createCL("act")
db.getCS("sample").createCL("org")
db.getCS("sample").createCL("staff")
db.getCS("sample").createCL("sales")
db.getCS("sample").createCL("product")
db.getCS("sample").createCL("inventory")
db.getCS("sample").createCL("customer")
db.getCS("sample").createCL("purchaseorder")
db.getCS("sample").createCL("catalog")
db.getCS("sample").createCL("suppliers")
db.getCS("sample").createCL("productsupplier")

sample=# create server sdb_server foreign data wrapper sdb_fdw options(address '127.0.0.1', service '11810', user 'sdbadmin', password 'sdbadmin', preferedinstance 'A', transaction 'on');
sample=# create foreign table emp (name text, id numeric) server sdb_server options ( collectionspace 'sample', collection 'emp', decimal 'on' ) ;

create server sdb_server foreign data wrapper sdb_fdw options(address '127.0.0.1', service '11810', user 'sdbadmin', password 'sdbadmin', preferedinstance 'A', transaction 'on');

create foreign table department  (
		  deptno char(3) not null , 
		  deptname varchar(36) not null , 
		  mgrno char(6) , 
		  admrdept char(3) not null , 
		  location char(16) ) 
 server sdb_server options ( collectionspace 'sample', collection 'department', decimal 'on' ) ;

create  foreign table employee  (
		  empno char(6) not null , 
		  firstnme varchar(12) not null , 
		  midinit char(1) , 
		  lastname varchar(15) not null , 
		  workdept char(3) , 
		  phoneno char(4) , 
		  hiredate date , 
		  job char(8) , 
		  edlevel smallint not null , 
		  sex char(1) , 
		  birthdate date , 
		  salary decimal(9,2) , 
		  bonus decimal(9,2) , 
		  comm decimal(9,2) ) 
 server sdb_server options ( collectionspace 'sample', collection 'employee', decimal 'on' ) ;

create foreign table project  (
		  projno char(6) not null , 
		  projname varchar(24) not null , 
		  deptno char(3) not null , 
		  respemp char(6) not null , 
		  prstaff decimal(5,2) , 
		  prstdate date , 
		  prendate date , 
		  majproj char(6) )  
 server sdb_server options ( collectionspace 'sample', collection 'project', decimal 'on' ) ; 

create foreign table projact  (
		  projno char(6) not null , 
		  actno smallint not null , 
		  acstaff decimal(5,2) , 
		  acstdate date not null , 
		  acendate date ) 
 server sdb_server options ( collectionspace 'sample', collection 'projact', decimal 'on' ) ; 

create foreign table empprojact  (
		  empno char(6) not null , 
		  projno char(6) not null , 
		  actno smallint not null , 
		  emptime decimal(5,2) , 
		  emstdate date , 
		  emendate date ) 
 server sdb_server options ( collectionspace 'sample', collection 'empprojact', decimal 'on' ) ; 

create foreign table act  (
		  actno smallint not null , 
		  actkwd char(6) not null , 
		  actdesc varchar(20) not null ) 
 server sdb_server options ( collectionspace 'sample', collection 'act', decimal 'on' ) ; 

create foreign table org  (
		  deptnumb smallint not null , 
		  deptname varchar(14) , 
		  manager smallint , 
		  division varchar(10) , 
		  location varchar(13) ) 
 server sdb_server options ( collectionspace 'sample', collection 'org', decimal 'on' ) ;  

create foreign table staff  (
		  id smallint not null , 
		  name varchar(9) , 
		  dept smallint , 
		  job char(5) , 
		  years smallint , 
		  salary decimal(7,2) , 
		  comm decimal(7,2) ) 
 server sdb_server options ( collectionspace 'sample', collection 'staff', decimal 'on' ) ;  

create foreign table sales  (
		  sales_date date , 
		  sales_person varchar(15) , 
		  region varchar(15) , 
		  sales integer ) 
 server sdb_server options ( collectionspace 'sample', collection 'sales', decimal 'on' ) ;  

create foreign table product  (
		  pid varchar(10) not null , 
		  name varchar(128) , 
		  price decimal(30,2) , 
		  promoprice decimal(30,2) , 
		  promostart date , 
		  promoend date , 
		  description text ) 
 server sdb_server options ( collectionspace 'sample', collection 'product', decimal 'on' ) ;  

create foreign table inventory  (
		  pid varchar(10) not null , 
		  quantity integer , 
		  location varchar(128) )
 server sdb_server options ( collectionspace 'sample', collection 'inventory', decimal 'on' ) ;  

create foreign table customer  (
		  cid bigint not null , 
		  name varchar(128) , 
                                  addr varchar(128)  ,
                                  phoneno char(11) ) 
 server sdb_server options ( collectionspace 'sample', collection 'customer', decimal 'on' ) ;  

create foreign table purchaseorder  (
		  poid bigint not null , 
		  status varchar(10) not null , 
		  custid bigint , 
		  orderdate date , 
		  porder varchar(1000) ) 
 server sdb_server options ( collectionspace 'sample', collection 'purchaseorder', decimal 'on' ) ;  

create foreign table catalog  (
		  name varchar(128) not null , 
		  catlog varchar(1000) ) 
 server sdb_server options ( collectionspace 'sample', collection 'catalog', decimal 'on' ) ;  

create foreign table suppliers  (
		  sid varchar(10) not null , 
                                  name varchar(128),
		  addr varchar(128) )  
 server sdb_server options ( collectionspace 'sample', collection 'suppliers', decimal 'on' ) ;  

create foreign table productsupplier  (
		  pid varchar(10) not null , 
		  sid varchar(10) not null )  
 server sdb_server options ( collectionspace 'sample', collection 'productsupplier', decimal 'on' ) ;  

drop foreign table department; 
drop foreign table employee;
drop foreign table project  ;
drop foreign table projact  ;
drop foreign table empprojact  ;
drop foreign table act  ;
drop foreign table org  ;
drop foreign table staff  ;
drop foreign table sales  ;
drop foreign table product  ;
drop foreign table inventory  ;
drop foreign table customer  ;
drop foreign table purchaseorder  ;
drop foreign table catalog  ;
drop foreign table suppliers  ;
drop foreign table productsupplier ;
drop server sdb_server;

connect to sample;

export to exp_sample_department.del of del messages msgs.txt select * from department ;
export to exp_sample_employee.del of del messages msgs.txt select * from employee ;
export to exp_sample_project.del of del messages msgs.txt select * from project ;
export to exp_sample_projact.del of del messages msgs.txt select * from projact ;
export to exp_sample_empprojact.del of del messages msgs.txt select * from empprojact ;
export to exp_sample_act.del of del messages msgs.txt select * from act ;
export to exp_sample_org.del of del messages msgs.txt select * from org ;
export to exp_sample_staff.del of del messages msgs.txt select * from staff ;
export to exp_sample_sales.del of del messages msgs.txt select * from sales ;
export to exp_sample_product.del of del messages msgs.txt select * from product ;
export to exp_sample_inventory.del of del messages msgs.txt select * from inventory ;
export to exp_sample_customer.del of del messages msgs.txt select * from customer ;
export to exp_sample_purchaseorder.del of del messages msgs.txt select * from purchaseorder ;
export to exp_sample_catalog.del of del messages msgs.txt select * from catalog ;
export to exp_sample_suppliers.del of del messages msgs.txt select * from suppliers ;
export to exp_sample_productsupplier.del of del messages msgs.txt select * from productsupplier ;

disconnect sample;

sdbimprt --hosts=localhost:11810 --type=csv --file=exp_sample_department.del -c sample -l department --headerline=true



