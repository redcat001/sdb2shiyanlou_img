/opt/sequoiasql/postgresql/bin/dropdb sample

sdb -f ./scripts/drop_cs_cl.js
