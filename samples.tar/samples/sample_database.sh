sdb -f ./scripts/create_cs_cl.js

sdbimprt --hosts=localhost:11810 --type=csv --file=./data/department.csv --fields="deptno string , deptname string , mgrno string , admrdept string , location string " --datefmt "YYYYMMDD" -c sample -l department
sdbimprt --hosts=localhost:11810 --type=csv --file=./data/employee.csv --fields="empno string, firstnme string,midinit string, lastname string, workdept string , phoneno string , hiredate date , job string , edlevel int , sex string,  birthdate date , salary decimal(9,2) , bonus decimal(9,2) , comm decimal(9,2) " --datefmt "YYYYMMDD" -c sample -l employee
sdbimprt --hosts=localhost:11810 --type=csv --file=./data/project.csv --fields="projno string , projname string , deptno string , respemp string , prstaff decimal(5,2) , prstdate date , prendate date , majproj string" --datefmt "YYYYMMDD" -c sample -l project
sdbimprt --hosts=localhost:11810 --type=csv --file=./data/projact.csv --fields="projno string , actno int , acstaff decimal(5,2) , acstdate date , acendate date" --datefmt "YYYYMMDD" -c sample -l projact
sdbimprt --hosts=localhost:11810 --type=csv --file=./data/empprojact.csv --fields="empno string , projno string , actno int , emptime decimal(5,2) , emstdate date , emendate date" --datefmt "YYYYMMDD" -c sample -l empprojact
sdbimprt --hosts=localhost:11810 --type=csv --file=./data/act.csv --fields="actno int , actkwd string , actdesc string " --datefmt "YYYYMMDD" -c sample -l act
sdbimprt --hosts=localhost:11810 --type=csv --file=./data/org.csv --fields="deptnumb int , deptname string , manager int , division string , location string" --datefmt "YYYYMMDD" -c sample -l org
sdbimprt --hosts=localhost:11810 --type=csv --file=./data/staff.csv --fields="id int , name string , dept int , job string , years int , salary decimal(7,2) , comm decimal(7,2)" --datefmt "YYYYMMDD" -c sample -l staff
sdbimprt --hosts=localhost:11810 --type=csv --file=./data/sales.csv --fields="sales_date date , sales_person string , region string , sales int" --datefmt "YYYYMMDD" -c sample -l sales
sdbimprt --hosts=localhost:11810 --type=csv --file=./data/product.csv --fields="pid string , name string , price decimal(30,2) , promoprice decimal(30,2) , promostart date , promoend date , description string" --datefmt "YYYYMMDD" -c sample -l product
sdbimprt --hosts=localhost:11810 --type=csv --file=./data/inventory.csv --fields="pid string , quantity int , location string " --datefmt "YYYYMMDD" -c sample -l inventory
sdbimprt --hosts=localhost:11810 --type=csv --file=./data/customer.csv --fields="cid int , name string , addr string  , phoneno string" --datefmt "YYYYMMDD" -c sample -l customer
sdbimprt --hosts=localhost:11810 --type=csv --file=./data/purchaseorder.csv --fields="poid int , status string , custid int , orderdate date , porder string" --datefmt "YYYYMMDD" -c sample -l purchaseorder
sdbimprt --hosts=localhost:11810 --type=csv --file=./data/catalog.csv --fields="name string , catlog string" --datefmt "YYYYMMDD" -c sample -l catalog
sdbimprt --hosts=localhost:11810 --type=csv --file=./data/suppliers.csv --fields="sid string , name string, addr string ,info string" --datefmt "YYYYMMDD" -c sample -l suppliers
sdbimprt --hosts=localhost:11810 --type=csv --file=./data/productsupplier.csv --fields="pid string , sid string " --datefmt "YYYYMMDD" -c sample -l productsupplier

/opt/sequoiasql/postgresql/bin/sdb_sql_ctl createdb sample myinst

psql -d sample -f ./scripts/create_sample_tables.sql
