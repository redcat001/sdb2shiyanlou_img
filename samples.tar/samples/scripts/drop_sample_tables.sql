drop foreign table department; 

drop foreign table employee;

drop foreign table project  ;

drop foreign table projact  ;

drop foreign table empprojact  ;

drop foreign table act  ;

drop foreign table org  ;

drop foreign table staff  ;

drop foreign table sales  ;

drop foreign table product  ;

drop foreign table inventory  ;

drop foreign table customer  ;

drop foreign table purchaseorder  ;

drop foreign table catalog  ;

drop foreign table suppliers  ;

drop foreign table productsupplier ;

drop server sdb_server;

drop extension sdb_fdw;
