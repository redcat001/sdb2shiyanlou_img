package com.sequoiadb.mysql;

import java.sql.*;

public class MySQLConnection {

    private String url;
    private String username;
    private String password;
    private String driver = "com.mysql.jdbc.Driver";

    public MySQLConnection(String url, String username, String password){
        this.url = url;
        this.username = username;
        this. password = password;
    }

    public Connection getConnection(){
        Connection connection = null;
        try {
            Class.forName(driver);
            connection = DriverManager.getConnection(url, username, password);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }
}
