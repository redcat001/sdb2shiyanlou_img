package com.sequoiadb.postgresql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Delete {
    private static String url = "jdbc:postgresql://127.0.0.1:5432/company";
    private static String username = "sdbadmin";
    private static String password = "";

    public static void main(String[] args) throws SQLException {
        delete();
    }

    public static void delete() throws SQLException {
        PostgreSQLConnection pgConnection = new PostgreSQLConnection(url, username, password);
        Connection connection = pgConnection.getConnection();
        String sql = "delete from employee where empno = ?";
        PreparedStatement psmt = connection.prepareStatement(sql);
        psmt.setInt(1, 10005);
        psmt.execute();
        connection.close();
    }
}
