package com.sequoiadb.postgresql;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class Insert {
    private static String url = "jdbc:postgresql://127.0.0.1:5432/company";
    private static String username = "sdbadmin";
    private static String password = "";
    public static void main(String[] args) throws SQLException {
        insert();
    }

    public static void insert() throws SQLException {
        PostgreSQLConnection pgConnection = new PostgreSQLConnection(url, username, password);
        Connection connection = pgConnection.getConnection();
        String sql = "INSERT INTO employee VALUES";
        Statement stmt = connection.createStatement();
        StringBuffer sb = new StringBuffer();
        sb.append("(").append(30001).append(",").append("'Mike'").append(",").append(20).append("),");
        sb.append("(").append(30002).append(",").append("'Donna'").append(",").append(21).append("),");
        sb.append("(").append(30003).append(",").append("'Jack'").append(",").append(22).append("),");
        sb.deleteCharAt(sb.length() - 1);
        sql = sql + sb.toString();
        System.out.println(sql);
        stmt.executeUpdate(sql);
        connection.close();
    }
}
